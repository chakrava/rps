/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rockpaperscissors;

/**
 * Represents what the agent knows of the world, specifically, the history of
 * the player's choices
 */
public class AgentModel {

    private int win = 0, loss = 0, tie = 0;//the win/loss/tie records
    private double choice;//a randomly generated number between 0 and 1, used to pick the computer's choice
    private int pickRock = 0, pickPaper = 0, pickScissors = 0;//how many times the player has picked each choice
    private int pickRockAgent = 0, pickPaperAgent = 0, pickScissorsAgent = 0;//how many times the agent has selected each choice
    private float chosenRock = 1 / (float) 3, chosenPaper = 2 / (float) 3;//used to set the ranges the computer uses to split up each choice

    public void tie() {
        tie++;
    }

    public void loss() {
        loss++;
    }

    public void win() {
        win++;
    }

    public int getWin() {
        return win;
    }

    public int getLoss() {
        return loss;
    }

    public int getTie() {
        return tie;
    }

    public int getPickRock() {
        return pickRock;
    }

    public int getPickPaper() {
        return pickPaper;
    }

    public int getPickScissors() {
        return pickScissors;
    }

    public float getChosenRock() {
        return chosenRock;
    }

    public float getChosenPaper() {
        return chosenPaper;
    }

    public int getPickRockAgent() {
        return pickRockAgent;
    }

    public int getPickPaperAgent() {
        return pickPaperAgent;
    }

    public int getPickScissorsAgent() {
        return pickScissorsAgent;
    }

    public double getChoice() {
        return choice;
    }

    //generates a random number and uses it to select a choice
    public String agentGetChoice() {
        choice = Math.random();
        if (choice <= chosenRock) {
            pickPaperAgent++;
            return "paper";
        } else if (choice <= chosenPaper) {
            pickScissorsAgent++;
            return "scissors";
        } else {
            pickRockAgent++;
            return "rock";
        }
    }

    //used to update the program on what choice the user made
    public void picked(String s) {
        s = s.toLowerCase();
        switch (s) {
            case "rock":
                pickRock++;
                update();
                break;
            case "paper":
                pickPaper++;
                update();
                break;
            case "scissors":
                pickScissors++;
                update();
                break;
            default:
                throw new RuntimeException("Invalid choice!");
        }
    }

    //updates the floats to adjust the chances the agent picks each choice
    private void update() {
        int totalPicks = pickRock + pickPaper + pickScissors;
        if (totalPicks < 10) {//if there's been less than 10 picks there's not enough data, don't change ranges
            return;
        }

        chosenRock = (float) pickRock / totalPicks;
        chosenPaper = 2 * (float) pickPaper / totalPicks;
        System.out.println(pickRock + " " + pickPaper + " " + pickScissors);
        System.out.println(chosenRock + " " + chosenPaper + " 1");
    }

}
