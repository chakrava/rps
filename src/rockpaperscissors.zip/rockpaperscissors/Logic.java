/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rockpaperscissors;

/**
 *
 */
public class Logic {

    //compares the selection of the user and AI and returns the winner (as a string)
    static String compareChoices(int user, int ai) {
        if (user == ai) {
            System.out.println("Tie");
            return "Tie";
        } else if (user == ai + 1 || (user == 0 && ai == 2)) {
            System.out.println("User wins!");
            return "User";
        } else {
            System.out.println("AI wins");
            return "AI";
        }
    }

    //turns an incoming string ("rock") into an integer (0)
    //"rock" = 0
    //"paper" = 1
    //"scissors" = 2
    static int ChoiceStringToInt(String s) {
        switch (s) {
            case "rock":
                return 0;
            case "paper":
                return 1;
            case "scissors":
                return 2;
            default:
                throw new RuntimeException("Invalid choice!");
        }
    }

}
